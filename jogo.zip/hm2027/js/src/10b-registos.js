// ============================= 10b-registos.js =============================
// Registos das ligas (recordes permanentes) — pedido do utilizador, 2026-10-05:
// "as ligas devem ter um separador de registos onde se guardam os nomes e numeros de: equipa com
// mais titulos, maior série vitórias, maior série de derrotas, jogos sem vencer, maior goleador de
// sempre, jogo com mais golos, maior vitoria, estes registos vao sendo actualizados sempre que
// sao ultrapassados e guardados para sempre".
//
// Desenho:
//  - state.registos.ligas[<divisionId>] guarda, por liga (placard, ok-liga, serie-a1, 2div, 3div),
//    os recordes atuais (nunca são apagados nem reiniciados entre épocas — só são substituídos
//    quando alguém os ULTRAPASSA estritamente; um empate mantém o titular mais antigo) e os
//    contadores de apoio (séries atuais por equipa, golos por jogador na liga).
//  - "Equipa com mais títulos" não precisa de contador próprio: calcula-se sempre a partir de
//    team.titulosClube (awardClubTitle, 08-evolucao-jogadores.js), que já é permanente e
//    retroativo — funciona mesmo em jogos gravados antes desta funcionalidade existir.
//  - Só contam jogos da fase regular da liga (nunca playoffs, taças, Europa, apuramentos).

  const REGISTOS_LIGAS = ["placard","ok-liga","serie-a1","2div","ok-liga-plata","3div"];
  const REGISTOS_LIGA_LABEL = { "placard":"Campeonato Placard", "ok-liga":"OK Liga", "serie-a1":"Serie A1", "2div":"2.ª Divisão", "ok-liga-plata":"OK Liga Plata", "3div":"3.ª Divisão" };
  // competicao (em team.titulosClube, ver updateReputations) do título de campeão de cada liga
  const REGISTOS_TITULO_COMPETICAO = { "placard":"placard", "ok-liga":"ok-liga", "serie-a1":"serie-a1", "2div":"2div-campeao", "ok-liga-plata":"ok-liga-plata-campeao", "3div":"3div-campeao" };

  function ensureRegistos(){
    if(!state.registos || typeof state.registos!=="object" || !state.registos.ligas) state.registos = { versao:1, ligas:{} };
    return state.registos;
  }
  function registosLiga(div){
    const r = ensureRegistos();
    if(!r.ligas[div]) r.ligas[div] = { series:{}, golos:{}, serieVitorias:null, serieDerrotas:null, serieSemVencer:null, goleador:null, jogoMaisGolos:null, maiorVitoria:null };
    return r.ligas[div];
  }
  // divisionId da competição se (e só se) for uma liga regular que conta para os registos.
  function registosDivisaoDaCompeticao(compId){
    const c = compId && state.competitions && state.competitions[compId];
    if(!c || !c.divisionId || String(c.id).includes("apuramento")) return null;
    return REGISTOS_LIGAS.includes(c.divisionId) ? c.divisionId : null;
  }
  function registosResultadoParaEquipa(souCasa, hs, as, soWinner){
    if(hs===as && soWinner) return ((soWinner==="home")===souCasa) ? "V" : "D";
    if(hs===as) return "E";
    return ((hs>as)===souCasa) ? "V" : "D";
  }
  function registosAtualizarSerie(liga, teamId, resultado, dataIso){
    const t = state.teams[teamId];
    if(!t) return;
    let s = liga.series[teamId];
    // Série interrompida por uma ausência de mais de uma época inteira desta liga (ex.: a equipa
    // subiu, desceu e só agora voltou) — não faz sentido continuar uma série antiga.
    if(!s || (state.season - (s.ep!=null ? s.ep : state.season)) > 1) s = liga.series[teamId] = { v:0, d:0, sv:0, ep:state.season };
    s.ep = state.season;
    if(resultado==="V"){ s.v++; s.d = 0; s.sv = 0; }
    else if(resultado==="D"){ s.d++; s.v = 0; s.sv++; }
    else { s.v = 0; s.d = 0; s.sv++; }
    const entrada = valor => ({ valor, teamId, nome:t.name, epoca:seasonLabel(state.season), data:dataIso });
    if(s.v  > (liga.serieVitorias ? liga.serieVitorias.valor : 0)) liga.serieVitorias = entrada(s.v);
    if(s.d  > (liga.serieDerrotas ? liga.serieDerrotas.valor : 0)) liga.serieDerrotas = entrada(s.d);
    if(s.sv > (liga.serieSemVencer ? liga.serieSemVencer.valor : 0)) liga.serieSemVencer = entrada(s.sv);
  }
  // Chamado por recordFixtureResult/recordFixtureResultFor (06-motor-jogo.js) quando um jogo da
  // fase regular fica registado — para TODOS os jogos da liga, também os 100% simulados pela IA.
  function registosRegistarJogoLiga(compId, homeId, awayId, hs, as, soWinner){
    const div = registosDivisaoDaCompeticao(compId);
    if(!div) return;
    const home = state.teams[homeId], away = state.teams[awayId];
    if(!home || !away) return;
    const liga = registosLiga(div);
    const dataIso = isoDate(state.currentDate || new Date());
    registosAtualizarSerie(liga, homeId, registosResultadoParaEquipa(true, hs, as, soWinner), dataIso);
    registosAtualizarSerie(liga, awayId, registosResultadoParaEquipa(false, hs, as, soWinner), dataIso);
    const total = hs + as, margem = Math.abs(hs - as);
    const jogo = { home:homeId, away:awayId, homeNome:home.name, awayNome:away.name, hs, as, epoca:seasonLabel(state.season), data:dataIso };
    if(total > (liga.jogoMaisGolos ? liga.jogoMaisGolos.total : -1)) liga.jogoMaisGolos = { ...jogo, total };
    if(margem > (liga.maiorVitoria ? liga.maiorVitoria.margem : 0)) liga.maiorVitoria = { ...jogo, margem, vencedor: hs>as ? "home" : "away" };
  }
  // Chamado quando as estatísticas de um jogo são creditadas aos jogadores (06-motor-jogo.js,
  // fim de partida) — só fase regular da liga (nunca playoff: ctx.isPlayoff).
  function registosCreditarGolos(compId, player, team, golos){
    if(!golos || !player || !team) return;
    const div = registosDivisaoDaCompeticao(compId);
    if(!div) return;
    const liga = registosLiga(div);
    let g = liga.golos[player.id];
    if(!g) g = liga.golos[player.id] = { n:0 };
    g.n += golos; g.nome = player.name; g.t = team.id; g.tn = team.name;
    // Ultrapassou o recorde (ou é o próprio titular a somar mais golos): passa a ser o titular.
    const rec = liga.goleador;
    if(!rec || g.n > rec.valor || rec.playerId===player.id){
      liga.goleador = { valor:g.n, playerId:player.id, nome:player.name, teamId:team.id, teamNome:team.name, epoca:seasonLabel(state.season) };
    }
  }
  // Equipa com mais títulos de campeão nesta liga (calculado a partir de team.titulosClube).
  // Desempate: fica com o recorde quem atingiu primeiro esse número de títulos.
  function registosEquipaMaisTitulos(div){
    const comp = REGISTOS_TITULO_COMPETICAO[div];
    let melhor = null;
    Object.values(state.teams||{}).forEach(t=>{
      const titulos = (t.titulosClube||[]).filter(x=>x && x.competicao===comp).sort((a,b)=>String(a.data).localeCompare(String(b.data)));
      if(!titulos.length) return;
      const cand = { valor:titulos.length, teamId:t.id, nome:t.name, data:titulos[titulos.length-1].data, epoca:titulos[titulos.length-1].epoca };
      if(!melhor || cand.valor>melhor.valor || (cand.valor===melhor.valor && String(cand.data)<String(melhor.data))) melhor = cand;
    });
    return melhor;
  }
  function registosLigasParaVista(){ return REGISTOS_LIGAS.map(d=>({ div:d, label:REGISTOS_LIGA_LABEL[d] })); }

  function registosLinhaEquipa(rec, sufixo){
    if(!rec) return `<td class="reg-nome reg-vazio">—</td><td class="num reg-valor">—</td><td class="reg-det"></td>`;
    const nome = state.teams[rec.teamId] ? teamLinkHtml(rec.teamId) : escapeHtml(rec.nome);
    return `<td class="reg-nome">${nome}</td><td class="num reg-valor"><b>${rec.valor}</b> ${sufixo}</td><td class="reg-det">${rec.epoca?escapeHtml(rec.epoca):""}</td>`;
  }
  function registosLinhaJogo(rec, valorFn){
    if(!rec) return `<td class="reg-nome reg-vazio">—</td><td class="num reg-valor">—</td><td class="reg-det"></td>`;
    const casa = state.teams[rec.home] ? teamLinkHtml(rec.home) : escapeHtml(rec.homeNome);
    const fora = state.teams[rec.away] ? teamLinkHtml(rec.away) : escapeHtml(rec.awayNome);
    return `<td class="reg-nome">${casa} <b>${rec.hs}-${rec.as}</b> ${fora}</td><td class="num reg-valor">${valorFn(rec)}</td><td class="reg-det">${escapeHtml(rec.epoca||"")}</td>`;
  }
  function registosHtmlParaLiga(div){
    const liga = registosLiga(div);
    const titulos = registosEquipaMaisTitulos(div);
    const g = liga.goleador;
    const golHtml = g
      ? `<td class="reg-nome">${escapeHtml(g.nome)} <span class="reg-clube">(${state.teams[g.teamId]?teamLinkHtml(g.teamId):escapeHtml(g.teamNome||"")})</span></td><td class="num reg-valor"><b>${g.valor}</b> golos</td><td class="reg-det">${escapeHtml(g.epoca||"")}</td>`
      : `<td class="reg-nome reg-vazio">—</td><td class="num reg-valor">—</td><td class="reg-det"></td>`;
    return `
      <div class="eyebrow" style="margin-bottom:8px;">Registos — ${REGISTOS_LIGA_LABEL[div]}</div>
      <table class="standings registos-table">
        <thead><tr><th>Registo</th><th>Nome</th><th class="num">Número</th><th>Época</th></tr></thead>
        <tbody>
          <tr><td class="reg-tipo">🏆 Equipa com mais títulos</td>${registosLinhaEquipa(titulos, "títulos")}</tr>
          <tr><td class="reg-tipo">🔥 Maior série de vitórias</td>${registosLinhaEquipa(liga.serieVitorias, "jogos")}</tr>
          <tr><td class="reg-tipo">📉 Maior série de derrotas</td>${registosLinhaEquipa(liga.serieDerrotas, "jogos")}</tr>
          <tr><td class="reg-tipo">⛔ Maior série sem vencer</td>${registosLinhaEquipa(liga.serieSemVencer, "jogos")}</tr>
          <tr><td class="reg-tipo">⚽ Maior goleador de sempre</td>${golHtml}</tr>
          <tr><td class="reg-tipo">🥅 Jogo com mais golos</td>${registosLinhaJogo(liga.jogoMaisGolos, r=>`<b>${r.total}</b> golos`)}</tr>
          <tr><td class="reg-tipo">💥 Maior vitória</td>${registosLinhaJogo(liga.maiorVitoria, r=>`<b>+${r.margem}</b> golos`)}</tr>
        </tbody>
      </table>
      <p class="helptext" style="margin-top:10px;">Os registos são atualizados automaticamente sempre que são ultrapassados e ficam guardados para sempre. Só contam jogos da fase regular da liga (a contagem de séries, golos e jogos começou com esta carreira; os títulos incluem toda a história registada).</p>`;
  }
  function renderRegistosTab(){
    const box = document.getElementById("historialRegistos");
    if(!box) return;
    const div = registosDivisaoDaCompeticao(state.viewedCompetitionId);
    if(!div){
      box.innerHTML = "";
      return;
    }
    box.innerHTML = registosHtmlParaLiga(div);
    box.querySelectorAll(".jr-team-link").forEach(btn=>btn.addEventListener("click", ()=>openClubFicha(btn.getAttribute("data-team"))));
  }
