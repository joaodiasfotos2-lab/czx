// =====================================================================
// 0.3.3 — Táticas com pista à escala + lista do plantel (convocados e titulares)
//
// Pedido do utilizador (2026-10-24): "ver a lista dos jogadores e alterar os convocados e
// titulares" + "uma pista de hóquei em patins em que mudam as posições dos jogadores conforme a
// tática e os nomes conforme os titulares". Decisões do utilizador sobre o mockup: pista
// horizontal; sem texto no piso; piso de tábuas de madeira; dimensões à escala (40 x 20 m, as
// do regulamento, não os limites máximos).
//
// Medidas (Regulamento Técnico FPP, art. 2): 1 m = 10 unidades (pista = 400 x 200). Área de
// penálti 9 x 5,40 m; linha de golo 1,70 m a 3 m do fundo (admite 2,70–3,30 m); semicírculo de
// protecção "de poste a poste" (raio 0,85 m); ponto de penálti a 5,40 m e de livre directo a
// 7,40 m do centro da linha de golo; círculo central de 3 m; cantos de 3 m.
//
// O motor de jogo não usa posições dentro do 3-1 / 2-2 (só quem é titular), por isso a posição
// em pista é apresentação: derivada de quem é titular (AVÇ para os lugares de avançado, DEF/MED
// para os restantes), com a possibilidade de o utilizador fixar a ordem arrastando (guardada em
// team.tacSlots[sistema]). Convocados/titulares usam os mesmos campos do Plantel
// (state.convocadosSelecionados e player.titular) — as duas vistas ficam sempre coerentes.
// =====================================================================
const TAC_SYS = {
  "3-1": { label:"3 DEF/MED + 1 AVÇ", slots:[
    {id:"GR",t:"GR",x:11,y:50},{id:"s1",t:"D",x:34,y:24},{id:"s2",t:"D",x:31,y:50},{id:"s3",t:"D",x:34,y:76},{id:"s4",t:"A",x:60,y:50}] },
  "2-2": { label:"2 DEF/MED + 2 AVÇ", slots:[
    {id:"GR",t:"GR",x:11,y:50},{id:"s1",t:"D",x:35,y:30},{id:"s2",t:"D",x:35,y:70},{id:"s3",t:"A",x:58,y:30},{id:"s4",t:"A",x:58,y:70}] },
  // losango: base (DEF/MED), dois alas (qualquer linha, lugar livre "W") e pivot (AVÇ)
  "1-2-1": { label:"base + 2 alas + pivot", slots:[
    {id:"GR",t:"GR",x:11,y:50},{id:"s1",t:"D",x:34,y:50,lab:"BASE"},{id:"s2",t:"W",x:47,y:21,lab:"ALA"},{id:"s3",t:"W",x:47,y:79,lab:"ALA"},{id:"s4",t:"A",x:63,y:50,lab:"PIVOT"}] }
};
const TAC_LAB = { GR:"GR", D:"DEF/MED", A:"AVÇ" };
let tacSelId = null;     // jogador seleccionado (clique + clique no lugar)
let tacDragId = null;
let tacMsgTimer = null;

function tacTeam(){ return myTeam(); }
function tacSistema(team){ return TAC_SYS[team.sistema] ? team.sistema : "3-1"; }
function tacKind(p){ return p.pos==="GR" ? "GR" : (p.linha==="Avancado" ? "A" : "D"); }
// lugar livre "W" (ala do 1-2-1) aceita qualquer jogador de campo
function tacFits(p, t){ return t==="W" ? p.pos!=="GR" : tacKind(p)===t; }
function tacIsConv(p){ return !!(state.convocadosSelecionados && state.convocadosSelecionados[p.id]); }
function tacSurname(name){
  const parts = String(name||"").trim().split(/\s+/);
  if(parts.length<2) return parts[0]||"";
  return parts[0][0]+". "+parts[parts.length-1];
}
function tacMsg(text){
  const el = document.getElementById("tpMsg"); if(!el) return;
  el.textContent = text; el.classList.add("show");
  clearTimeout(tacMsgTimer); tacMsgTimer = setTimeout(()=>el.classList.remove("show"), 2600);
}
function tacCounts(team){
  const c = { convGR:0, convJ:0, titGR:0, titJ:0 };
  team.players.forEach(p=>{
    if(!tacIsConv(p)) return;
    if(p.pos==="GR"){ c.convGR++; if(p.titular) c.titGR++; } else { c.convJ++; if(p.titular) c.titJ++; }
  });
  return c;
}

// ---------- disposição do onze em pista ----------
// Devolve [{slot, player|null, out}] para o sistema pedido. Primeiro respeita os lugares fixados
// pelo utilizador; depois coloca cada titular de campo no lugar do seu tipo (AVÇ→avançado,
// DEF/MED→defesa/médio); o que sobrar vai para o primeiro lugar livre e aparece com ⚠.
function tacLayout(team, sistema, over){
  const sys = TAC_SYS[sistema];
  // `over` (0.4.6): onze que está MESMO em pista durante a partida ao vivo ({gr, field}).
  const gr = over ? (over.gr||null) : (team.players.find(p=>p.pos==="GR" && p.titular && tacIsConv(p)) || null);
  let field = over ? over.field.slice() : team.players.filter(p=>p.pos==="J" && p.titular && tacIsConv(p));
  if(field.length>4) field = field.slice(0,4);
  const pins = (team.tacSlots && team.tacSlots[sistema]) || {};
  const slotsOut = sys.slots.filter(s=>s.t!=="GR");
  const assigned = {};
  const used = new Set();
  slotsOut.forEach(s=>{
    const pid = pins[s.id];
    const pl = pid && field.find(p=>p.id===pid && !used.has(p.id));
    if(pl){ assigned[s.id] = pl; used.add(pl.id); }
  });
  const rank = p => -overall(p);
  // primeiro os lugares com tipo fixo; os lugares livres (alas) ficam com os melhores que sobrarem
  slotsOut.filter(s=>s.t!=="W").concat(slotsOut.filter(s=>s.t==="W")).forEach(s=>{
    if(assigned[s.id]) return;
    const cand = field.filter(p=>!used.has(p.id) && tacFits(p, s.t)).sort((a,b)=>rank(a)-rank(b))[0];
    if(cand){ assigned[s.id] = cand; used.add(cand.id); }
  });
  slotsOut.forEach(s=>{
    if(assigned[s.id]) return;
    const cand = field.filter(p=>!used.has(p.id)).sort((a,b)=>rank(a)-rank(b))[0];
    if(cand){ assigned[s.id] = cand; used.add(cand.id); }
  });
  return sys.slots.map(s=>{
    const player = s.t==="GR" ? gr : (assigned[s.id]||null);
    return { slot:s, player, out: !!(player && s.t!=="GR" && !tacFits(player, s.t)) };
  });
}
function tacPin(team, sistema, slotId, playerId){
  if(!team.tacSlots) team.tacSlots = {};
  if(!team.tacSlots[sistema]) team.tacSlots[sistema] = {};
  const pins = team.tacSlots[sistema];
  Object.keys(pins).forEach(k=>{ if(pins[k]===playerId) delete pins[k]; });
  if(slotId) pins[slotId] = playerId;
}
function tacUnpinPlayer(team, playerId){
  if(!team.tacSlots) return;
  Object.keys(team.tacSlots).forEach(sis=>{
    const pins = team.tacSlots[sis];
    Object.keys(pins).forEach(k=>{ if(pins[k]===playerId) delete pins[k]; });
  });
}

// ---------- alterações de estado (convocado / suplente / titular) ----------
function tacSetStatus(team, p, estado, opts){
  const quiet = opts && opts.quiet;
  if(convIndisponivelMotivo(p)){ if(!quiet) tacMsg(p.name+": indisponível ("+convIndisponivelMotivo(p).toLowerCase()+")."); return false; }
  // Só pode haver um GR titular: pedir outro GR titular despromove o anterior (como no Plantel).
  const demotedGR = [];
  if(estado==="titular" && p.pos==="GR"){
    team.players.forEach(o=>{ if(o.pos==="GR" && o.id!==p.id && o.titular){ o.titular = false; demotedGR.push(o); } });
  }
  const counts = tacCounts(team);
  if(!convOptionAllowed(p, estado, counts)){
    demotedGR.forEach(o=>{ o.titular = true; });
    if(!quiet){
      const isGR = p.pos==="GR";
      if(estado==="titular" && !(isGR)) tacMsg("Já há 4 jogadores de campo no onze — tira um primeiro.");
      else tacMsg("Limite de convocados atingido ("+(isGR?"2 GR":"8 jogadores de campo")+").");
    }
    return false;
  }
  if(estado==="nao"){ state.convocadosSelecionados[p.id] = false; p.titular = false; tacUnpinPlayer(team, p.id); }
  else if(estado==="suplente"){ state.convocadosSelecionados[p.id] = true; p.titular = false; tacUnpinPlayer(team, p.id); }
  else {
    state.convocadosSelecionados[p.id] = true; p.titular = true;
  }
  return true;
}
// Pôr `p` no lugar `slotId`: se o lugar estiver ocupado, quem lá estava volta a suplente (ou, se
// `p` já era titular, os dois trocam de lugar).
function tacPlaceInSlot(team, p, slotId){
  const sis = tacSistema(team);
  const lay = tacLayout(team, sis);
  const target = lay.find(x=>x.slot.id===slotId); if(!target) return;
  const isGRSlot = target.slot.t==="GR";
  if((p.pos==="GR") !== isGRSlot){ tacMsg(isGRSlot ? "Só um guarda-redes pode ocupar a baliza." : "O guarda-redes não joga em campo."); return; }
  const here = lay.find(x=>x.player && x.player.id===p.id);
  const other = target.player && target.player.id!==p.id ? target.player : null;
  if(here){
    // troca de lugares entre dois titulares (ou mudança para um lugar vazio)
    if(isGRSlot) return;
    if(other) tacPin(team, sis, here.slot.id, other.id);
    tacPin(team, sis, slotId, p.id);
    return;
  }
  // vem da lista/banco: despromove quem lá estava (se o onze já está completo nesse tipo)
  if(other){
    if(!tacSetStatus(team, other, "suplente", {quiet:true})) return;
  }
  if(!tacSetStatus(team, p, "titular")) return;
  if(!isGRSlot) tacPin(team, sis, slotId, p.id);
}
function tacAutoBest(team){
  const sis = tacSistema(team);
  const gr = bestGK(team);
  const field = bestOutfieldForSystem(team, sis).filter(p=>playerAvailableForMatch(p)).slice(0,4);
  team.players.forEach(p=>{ p.titular = false; });
  if(gr && playerAvailableForMatch(gr)){ state.convocadosSelecionados[gr.id] = true; gr.titular = true; }
  field.forEach(p=>{ state.convocadosSelecionados[p.id] = true; p.titular = true; });
  // tectos de convocatória: retira primeiro os suplentes menos úteis
  [["GR",CONVOCATORIA_MAX_GR],["J",CONVOCATORIA_MAX_J]].forEach(([pos,max])=>{
    const conv = team.players.filter(p=>p.pos===pos && tacIsConv(p));
    if(conv.length<=max) return;
    conv.filter(p=>!p.titular).sort((a,b)=>overall(a)-overall(b)).slice(0, conv.length-max).forEach(p=>{ state.convocadosSelecionados[p.id] = false; });
  });
  if(team.tacSlots) delete team.tacSlots[sis];
}
function tacClearEleven(team){
  team.players.forEach(p=>{ if(p.titular){ p.titular = false; } });
  team.tacSlots = {};
}

// ---------- desenho da pista (SVG à escala + piso de madeira) ----------
function tacSeeded(seed){ return () => { seed = (seed*1664525 + 1013904223) % 4294967296; return seed/4294967296; }; }
function tacRinkSvg(){
  const M = 8, L = 400, W = 200, R = tacSeeded(7);
  const pal = ["#e9bd73","#e2b366","#eec582","#dfaa5e","#e6b86c","#ebc07a"];
  let wood = "";
  for(let r=0;r<W/4;r++){
    let x = -R()*70; const y = r*4;
    while(x<L){
      const len = 45+R()*75, c = pal[Math.floor(R()*pal.length)];
      wood += `<rect x="${x.toFixed(1)}" y="${y}" width="${len.toFixed(1)}" height="4" fill="${c}"/>`;
      wood += `<line x1="${x.toFixed(1)}" y1="${y}" x2="${x.toFixed(1)}" y2="${y+4}" stroke="#8a5a1f" stroke-opacity=".45" stroke-width=".3"/>`;
      x += len;
    }
    wood += `<line x1="0" y1="${y}" x2="${L}" y2="${y}" stroke="#8a5a1f" stroke-opacity=".38" stroke-width=".3"/>`;
  }
  const ln = "#1d1409";
  const half = g => {
    const X = x => g ? L-x : x;
    return `
      <rect x="${g?L-84:30}" y="55" width="54" height="90" fill="#b9651f" fill-opacity=".26" stroke="${ln}" stroke-width="1"/>
      <path d="M${X(30)} 91.5 A8.5 8.5 0 0 ${g?0:1} ${X(30)} 108.5 Z" fill="#b9651f" fill-opacity=".30" stroke="${ln}" stroke-width="1"/>
      <line x1="${X(30)}" y1="91.5" x2="${X(30)}" y2="108.5" stroke="${ln}" stroke-width="1"/>
      <rect x="${g?L-30:24}" y="91.5" width="6" height="17" fill="url(#tacNet)" stroke="#ff7a1a" stroke-width="1.3"/>
      <circle cx="${X(84)}" cy="100" r="1.3" fill="${ln}" stroke="none"/>
      <circle cx="${X(104)}" cy="100" r="1.3" fill="${ln}" stroke="none"/>`;
  };
  return `<svg viewBox="0 0 ${L} ${W}" preserveAspectRatio="none" aria-hidden="true">
    <defs>
      <clipPath id="tacPc"><rect width="${L}" height="${W}" rx="30"/></clipPath>
      <radialGradient id="tacShade" cx=".5" cy=".5" r=".75"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset="1" stop-color="#5a3508" stop-opacity=".22"/></radialGradient>
      <pattern id="tacNet" width="2.5" height="2.5" patternUnits="userSpaceOnUse"><rect width="2.5" height="2.5" fill="rgba(255,255,255,.55)"/><path d="M0 0H2.5V2.5" fill="none" stroke="rgba(60,60,60,.55)" stroke-width=".25"/></pattern>
    </defs>
    <g clip-path="url(#tacPc)">${wood}<rect width="${L}" height="${W}" fill="url(#tacShade)"/></g>
    <g fill="none" stroke="${ln}" stroke-width="1" stroke-linejoin="round">
      <line x1="200" y1="0" x2="200" y2="${W}"/><circle cx="200" cy="100" r="30"/>${half(0)}${half(1)}
    </g>
    <circle cx="200" cy="100" r="1.5" fill="${ln}"/>
    <rect x="1.5" y="1.5" width="${L-3}" height="${W-3}" rx="29" fill="none" stroke="#2b3556" stroke-width="3"/>
  </svg>`;
}

// ---------- HTML ----------
function tacRowHtml(p, counts){
  const motivo = convIndisponivelMotivo(p);
  const st = convStatusFor(p);
  const cond = Math.round(p.condicao!=null ? p.condicao : 100);
  const k = tacKind(p);
  const btn = (v,label) => {
    const on = st===v;
    const dis = motivo || (!on && !convOptionAllowed(p, v, counts));
    return `<button type="button" class="tp-st tp-st-${v}${on?" on":""}" data-tp-st="${v}" data-id="${p.id}"${dis?" disabled":""} title="${v==="nao"?"Fora da convocatória":v==="suplente"?"Suplente convocado":"Titular"}">${label}</button>`;
  };
  return `<div class="tp-row${motivo?" off":""}${tacSelId===p.id?" sel":""}" data-tp-p="${p.id}" draggable="${motivo?"false":"true"}">
    <span class="tp-nn">${p.num}</span>
    <span class="tp-pn"><button type="button" class="playername-btn" data-id="${p.id}">${playerNameHtml(p)}</button>${motivo?`<small>${escapeHtml(motivo)}${(p.diasLesao||0)>0?` (${p.diasLesao} dias)`:(p.suspensoJogos||0)>0?` (${p.suspensoJogos} jogo${p.suspensoJogos>1?"s":""})`:""}</small>`:""}</span>
    <span class="tp-pb tp-pb-${k}">${linhaAbbrev(p)}</span>
    <span class="tp-ovr">${overall(p)}</span>
    <span class="tp-cond"><i style="width:${cond}%;background:${fitnessColor(cond)}"></i></span>
    <span class="tp-stbox">${btn("nao","—")}${btn("suplente","S")}${btn("titular","T")}</span>
  </div>`;
}
function tacListHtml(team){
  const counts = tacCounts(team);
  const order = {GR:0,D:1,A:2};
  const sorter = (a,b)=> (order[tacKind(a)]-order[tacKind(b)]) || (overall(b)-overall(a));
  const disp = team.players.filter(p=>!convIndisponivelMotivo(p));
  // Uma única lista (sem cabeçalhos de secção, para o ecrã nunca ter scroll): onze, suplentes, resto.
  // O estado de cada um vê-se nos botões — / S / T.
  const linhas = disp.filter(p=>tacIsConv(p) && p.titular).sort(sorter)
    .concat(disp.filter(p=>tacIsConv(p) && !p.titular).sort(sorter))
    .concat(disp.filter(p=>!tacIsConv(p)).sort(sorter));
  const indisp = team.players.filter(p=>convIndisponivelMotivo(p)).sort(sorter);
  const curto = (p) => {
    const m = convIndisponivelMotivo(p) || "";
    if((p.suspensoJogos||0)>0) return `Suspenso (${p.suspensoJogos}j)`;
    if((p.diasLesao||0)>0) return `Lesionado (${p.diasLesao}d)`;
    if(/selec/i.test(m)) return "Selecção";
    return m.length>18 ? m.slice(0,16)+"…" : m;
  };
  const chips = indisp.length
    ? `<div class="tp-sec"><span>Indisponíveis</span><span>${indisp.length}</span></div><div class="tp-unv">${indisp.map(p=>`<span class="tp-unv-chip" title="${escapeHtml(p.name+" — "+(convIndisponivelMotivo(p)||""))}"><button type="button" class="playername-btn" data-id="${p.id}">${playerNameHtml(p)}</button><em>${escapeHtml(curto(p))}</em></span>`).join("")}</div>`
    : "";
  return linhas.map(p=>tacRowHtml(p,counts)).join("") + chips;
}
function tacKpisHtml(team, lay, sis){
  const counts = tacCounts(team);
  const placed = lay.filter(x=>x.player);
  const ovr = placed.length ? placed.reduce((a,x)=>a+overall(x.player),0)/placed.length : 0;
  const fora = lay.filter(x=>x.out).length;
  const conv = counts.convGR + counts.convJ;
  const fit = Math.round(systemFitScore(team, sis));
  const cls = (v,good,mid) => v>=good ? "ok" : v>=mid ? "warn" : "bad";
  return `
    <div class="tp-kpi ${cls(fit,70,50)}"><b>${fit}</b><span>Adequação ao ${sis}</span></div>
    <div class="tp-kpi"><b>${placed.length?ovr.toFixed(1):"—"}</b><span>OVR do onze</span></div>
    <div class="tp-kpi ${conv>10?"bad":conv===10?"ok":"warn"}"><b>${conv}/10</b><span>Convocados</span></div>
    <div class="tp-kpi ${fora?"warn":"ok"}"><b>${fora}</b><span>Fora de posição</span></div>`;
}
function tacBenchHtml(team){
  const bench = team.players.filter(p=>tacIsConv(p) && !p.titular && !convIndisponivelMotivo(p))
    .sort((a,b)=>({GR:0,D:1,A:2}[tacKind(a)]-{GR:0,D:1,A:2}[tacKind(b)]) || (overall(b)-overall(a)));
  if(!bench.length) return `<span class="tp-empty">Sem suplentes convocados.</span>`;
  return bench.map(p=>`<span class="tp-chip${tacSelId===p.id?" sel":""}" draggable="true" data-tp-p="${p.id}" title="${escapeHtml(p.name)} · ${linhaAbbrev(p)} · OVR ${overall(p)}"><i class="tp-dot tp-dot-${tacKind(p)}">${p.num}</i>${escapeHtml(tacSurname(p.name))}<em>${overall(p)}</em></span>`).join("");
}

// Corpo da pista, usado pelo separador Táticas (renderTaticasView). Os botões de sistema
// mantêm data-sistema dentro de .tactic-row, para continuarem sincronizados com o painel ao vivo.
function tacPistaHtml(team){
  const sis = tacSistema(team);
  ensureSquadSelectionDefaults();
  return `<div id="tacPista" class="tp">
    <div class="tp-top">
      <div>
        <div class="eyebrow" style="margin-bottom:6px;">Sistema</div>
        <div class="tactic-row" id="sistemaRow" style="margin-top:0;">
          <button class="tactic-btn" data-sistema="3-1" title="3-1 (3 DEF/MED + 1 AVÇ): mais circulação, mais controlo de posse e melhor cobertura defensiva; o avançado isolado precisa de saber jogar como referência.">3-1<span class="tp-fitn" title="Adequação do plantel ao 3-1">${Math.round(systemFitScore(team,"3-1"))}</span><small>3 DEF/MED + 1 AVÇ</small></button>
          <button class="tactic-btn" data-sistema="2-2" title="2-2 (2 DEF/MED + 2 AVÇ): mais presença ofensiva, combinações e transições; maior exposição defensiva e desgaste dos DEF/MED.">2-2<span class="tp-fitn" title="Adequação do plantel ao 2-2">${Math.round(systemFitScore(team,"2-2"))}</span><small>2 DEF/MED + 2 AVÇ</small></button>
          <button class="tactic-btn" data-sistema="1-2-1" title="1-2-1 (losango: base + 2 alas + pivot): o base distribui, os alas jogam abertos e rápidos, o pivot joga de costas junto à baliza; pede base criativo, alas móveis e pivot forte, e fica exposto ao contra-ataque quando o base perde a bola. O motor não bloqueia jogadores fora de posição, mas penaliza a organização colectiva.">1-2-1<span class="tp-fitn" title="Adequação do plantel ao 1-2-1">${Math.round(systemFitScore(team,"1-2-1"))}</span><small>base + 2 alas + pivot</small></button>
        </div>
      </div>
      <div class="tp-kpis" id="tpKpis"></div>
    </div>
    <div class="tp-main">
      <div class="tp-left">
        <div class="tp-rink" id="tpRink">${tacRinkSvg()}<div class="tp-play" id="tpPlay"></div></div>
        <div class="tp-legend"><span><i class="tp-dot tp-dot-GR"></i>Guarda-redes</span><span><i class="tp-dot tp-dot-D"></i>Defesa/Médio</span><span><i class="tp-dot tp-dot-A"></i>Avançado</span><span><i class="tp-dot tp-dot-W">!</i>Fora de posição</span><span class="tp-dir">A defender ← · → a atacar</span></div>
        <div class="tp-sec"><span>Banco (convocados)</span><span id="tpBenchC"></span></div>
        <div class="tp-bench" id="tpBench"></div>
        <p class="helptext tp-note" id="tpHint"></p>
      </div>
      <div class="tp-right">
        <div class="tp-sec tp-sec-head" title="Máx. 2 GR + 8 de campo convocados; onze: 1 GR + 4. Arrasta um jogador para a pista ou usa — / S / T (fora / suplente / titular)."><span>Plantel</span><span id="tpConvC"></span></div>
        <div class="tp-list" id="tpList"></div>
        
        <div class="tp-foot"><button type="button" class="tactic-btn" id="tpAuto">⚡ Escolher o melhor onze</button><button type="button" class="tactic-btn" id="tpClear">Limpar onze</button></div>
      </div>
    </div>
    <div class="tp-msg" id="tpMsg"></div>
  </div>`;
}

// Actualiza tudo o que depende do onze/sistema. Os marcadores dos jogadores são reaproveitados
// (por id) para que, ao mudar de sistema, deslizem para a nova posição em vez de saltar.
function tacPistaRefresh(){
  const root = document.getElementById("tacPista"); if(!root) return;
  const team = tacTeam(); if(!team) return;
  const sis = tacSistema(team);
  const lay = tacLayout(team, sis);
  const play = document.getElementById("tpPlay");
  const existing = {};
  play.querySelectorAll(".tp-tok").forEach(t=>{ existing[t.dataset.tpP] = t; });
  play.querySelectorAll(".tp-slot").forEach(s=>s.remove());
  const keep = new Set();
  lay.forEach(x=>{
    const s = x.slot;
    const slot = document.createElement("div");
    slot.className = "tp-slot tp-slot-"+s.t; slot.dataset.slot = s.id;
    slot.style.left = s.x+"%"; slot.style.top = s.y+"%";
    slot.innerHTML = x.player ? "" : (s.lab || TAC_LAB[s.t]).replace("/","/<br>");
    play.appendChild(slot);
    if(!x.player) return;
    const p = x.player; keep.add(p.id);
    let tok = existing[p.id];
    const cond = Math.round(p.condicao!=null ? p.condicao : 100);
    const isNew = !tok;
    if(isNew){ tok = document.createElement("div"); tok.draggable = true; tok.dataset.tpP = p.id; play.appendChild(tok); }
    tok.className = "tp-tok tp-tok-"+tacKind(p)+(x.out?" out":"")+(tacSelId===p.id?" sel":"");
    tok.dataset.slot = s.id;
    tok.title = p.name+" · "+(p.pos==="GR"?"GR":TAC_LAB[tacKind(p)])+(x.out?" — fora de posição neste sistema":"");
    tok.innerHTML = `<div class="tp-sh">${p.num}<span class="tp-ov">${overall(p)}</span>${x.out?'<span class="tp-wr">!</span>':''}</div><div class="tp-nm">${escapeHtml(tacSurname(p.name))}</div><div class="tp-cb"><i style="width:${cond}%;background:${fitnessColor(cond)}"></i></div>`;
    if(isNew){ tok.style.left = s.x+"%"; tok.style.top = s.y+"%"; }
    else { tok.style.left = s.x+"%"; tok.style.top = s.y+"%"; }
  });
  Object.keys(existing).forEach(id=>{ if(!keep.has(id)) existing[id].remove(); });
  document.getElementById("tpKpis").innerHTML = tacKpisHtml(team, lay, sis);
  document.getElementById("tpBench").innerHTML = tacBenchHtml(team);
  document.getElementById("tpList").innerHTML = tacListHtml(team);
  const counts = tacCounts(team);
  document.getElementById("tpConvC").textContent = `GR ${counts.convGR}/${CONVOCATORIA_MAX_GR} · J ${counts.convJ}/${CONVOCATORIA_MAX_J}`;
  document.getElementById("tpBenchC").textContent = `${team.players.filter(p=>tacIsConv(p) && !p.titular && !convIndisponivelMotivo(p)).length} no banco`;
  const faltam = (lay.filter(x=>!x.player).length);
  const hint = document.getElementById("tpHint");
  hint.textContent = faltam ? `Faltam ${faltam} titular${faltam>1?"es":""} no onze — se ficar assim, o treinador completa o onze com os melhores disponíveis.` : "";
  hint.style.display = faltam ? "" : "none";
  if(typeof syncTaticasUI==="function") syncTaticasUI();
}

// ---------- interacção (delegada, ligada uma única vez) ----------
function tacAfterChange(){
  tacSelId = null;
  tacPistaRefresh();
  if(typeof renderRoster==="function" && document.getElementById("rosterBody")){ try{ renderRoster(); }catch(e){} }
}
document.addEventListener("click", (e) => {
  const root = e.target.closest("#tacPista"); if(!root) return;
  const team = tacTeam(); if(!team) return;
  const st = e.target.closest("[data-tp-st]");
  if(st && !st.disabled){
    const p = team.players.find(pl=>pl.id===st.dataset.id); if(!p) return;
    if(tacSetStatus(team, p, st.dataset.tpSt)) tacAfterChange();
    return;
  }
  if(e.target.closest("#tpAuto")){ tacAutoBest(team); tacAfterChange(); tacMsg("Melhor onze para o "+tacSistema(team)+" escolhido."); return; }
  if(e.target.closest("#tpClear")){ tacClearEleven(team); tacAfterChange(); return; }
  const nomeBtn = e.target.closest(".playername-btn");
  if(nomeBtn){ // clicar no nome abre o perfil do jogador
    if(typeof openPlayerModal==="function") openPlayerModal(nomeBtn.dataset.team || team.id, nomeBtn.dataset.id);
    return;
  }
  const slot = e.target.closest(".tp-slot, .tp-tok");
  if(slot && tacSelId){
    const p = team.players.find(pl=>pl.id===tacSelId);
    if(p && (!slot.dataset.tpP || slot.dataset.tpP!==p.id)){ tacPlaceInSlot(team, p, slot.dataset.slot); tacAfterChange(); return; }
  }
  const item = e.target.closest(".tp-tok, .tp-row, .tp-chip");
  if(item && item.dataset.tpP){
    const id = item.dataset.tpP;
    const p = team.players.find(pl=>pl.id===id);
    if(p && convIndisponivelMotivo(p)){ tacMsg(p.name+": indisponível ("+convIndisponivelMotivo(p).toLowerCase()+")."); return; }
    tacSelId = tacSelId===id ? null : id;
    tacPistaRefresh();
  }
});
document.addEventListener("dragstart", (e) => {
  const it = e.target.closest && e.target.closest("#tacPista [data-tp-p]"); if(!it) return;
  tacDragId = it.dataset.tpP;
  try{ e.dataTransfer.setData("text/plain", tacDragId); e.dataTransfer.effectAllowed = "move"; }catch(_){}
  it.classList.add("drag");
});
document.addEventListener("dragend", () => {
  tacDragId = null;
  document.querySelectorAll("#tacPista .drag").forEach(x=>x.classList.remove("drag"));
  document.querySelectorAll("#tacPista .tp-slot.over").forEach(x=>x.classList.remove("over"));
});
document.addEventListener("dragover", (e) => {
  if(!tacDragId) return;
  const zone = e.target.closest && e.target.closest("#tacPista .tp-slot, #tacPista .tp-tok, #tacPista .tp-list, #tacPista .tp-bench");
  if(!zone) return;
  e.preventDefault();
  document.querySelectorAll("#tacPista .tp-slot.over").forEach(x=>x.classList.remove("over"));
  const sid = zone.dataset && zone.dataset.slot;
  if(sid){ const sl = document.querySelector('#tacPista .tp-slot[data-slot="'+sid+'"]'); if(sl) sl.classList.add("over"); }
});
document.addEventListener("drop", (e) => {
  if(!tacDragId) return;
  const zone = e.target.closest && e.target.closest("#tacPista .tp-slot, #tacPista .tp-tok, #tacPista .tp-list, #tacPista .tp-bench");
  if(!zone) return;
  e.preventDefault();
  const team = tacTeam(); if(!team) return;
  const p = team.players.find(pl=>pl.id===tacDragId); if(!p) return;
  if(zone.dataset && zone.dataset.slot){
    tacPlaceInSlot(team, p, zone.dataset.slot);
  } else if(zone.classList.contains("tp-bench")){
    if(convStatusFor(p)==="nao") tacSetStatus(team, p, "suplente"); else if(p.titular) tacSetStatus(team, p, "suplente");
  } else if(zone.classList.contains("tp-list")){
    if(p.titular) tacSetStatus(team, p, "suplente"); else if(convStatusFor(p)==="nao") tacSetStatus(team, p, "suplente");
  }
  tacDragId = null;
  tacAfterChange();
});


// ---------- sem scroll no menu das Tácticas ----------
// O ecrã tem de caber sempre na janela: depois da compactação por CSS, se ainda for mais alto do
// que o espaço disponível, reduz-se a escala do conteúdo (zoom) o mínimo necessário.
let tacFitBusy = false;
function tacFitNoScroll(){
  if(tacFitBusy) return;
  const v = document.getElementById("viewTaticas"), box = document.getElementById("taticasContent");
  if(!v || !box || v.classList.contains("hidden")) return;
  tacFitBusy = true;
  try{
    box.style.zoom = ""; box.style.removeProperty("--tks");
    const rink = document.getElementById("tpRink");
    if(rink) rink.style.width = "";
    // 1.º: encolher só a pista (a letra mantém o tamanho); 2.º: em último caso, um zoom ligeiro (mín. 0,82).
    if(rink && rink.offsetParent){
      const colW = rink.parentElement.clientWidth || 1;
      const esq = rink.closest(".tp-left"), dir = document.querySelector("#tacPista .tp-right");
      for(let i=0;i<6;i++){
        const over = v.scrollHeight - v.clientHeight;
        if(over <= 0) break;
        // Só adianta encolher a pista enquanto a coluna da esquerda for a mais alta.
        const folga = esq && dir ? esq.offsetHeight - dir.offsetHeight : over;
        const d = Math.min(over, folga);
        if(d <= 1) break;
        const novoW = Math.max(colW*0.55, (rink.offsetHeight - d - 2) * 2);
        const k = Math.min(1, novoW / colW);
        rink.style.width = (k*100)+"%"; rink.style.marginInline = "auto";
        box.style.setProperty("--tks", String(Math.max(0.78, k)));
        if(k <= 0.55) break;
      }
    }
    let z = 1;
    for(let i=0;i<4;i++){
      const over = v.scrollHeight - v.clientHeight;
      if(over <= 0) break;
      const alvo = Math.max(0.82, z * (v.clientHeight - 6) / v.scrollHeight);
      if(Math.abs(alvo - z) < 0.002) break;
      z = alvo; box.style.zoom = String(z);
    }
  } finally { tacFitBusy = false; }
}
let tacFitRaf = 0;
function tacFitSoon(){ if(tacFitRaf) return; tacFitRaf = requestAnimationFrame(()=>{ tacFitRaf = 0; tacFitNoScroll(); }); }
(function(){
  const ligar = () => {
    const v = document.getElementById("viewTaticas"); if(!v) return;
    const mo = new MutationObserver(tacFitSoon);
    mo.observe(v, { attributes:true, attributeFilter:["class"] });
    const box = document.getElementById("taticasContent");
    if(box) mo.observe(box, { childList:true, subtree:true, attributes:true, attributeFilter:["class"] });
    window.addEventListener("resize", tacFitSoon);
  };
  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", ligar); else ligar();
})();


// =====================================================================
// 0.4.6 — Táticas durante a partida: a mesma pista do separador Táticas do clube, mas com o onze
// que está MESMO em pista e o banco da partida. Substituição por dois toques (suplente + quem sai,
// por qualquer ordem) ou arrastando; usa performSub, tal como o diálogo antigo.
// =====================================================================
let ltSel = null;     // {id, from:"bench"|"rink"}
let ltDragId = null;
let ltMsgTimer = null;
function ltMsg(text){
  const host = document.querySelector(".lt-pitchcol"); if(!host) return;
  let el = document.getElementById("ltMsg");
  if(!el){ el = document.createElement("div"); el.id = "ltMsg"; el.className = "lt-msg"; host.appendChild(el); }
  el.textContent = text; el.classList.add("show");
  clearTimeout(ltMsgTimer); ltMsgTimer = setTimeout(()=>el.classList.remove("show"), 2600);
}
function ltPlayerById(ctx, side, id){
  const lu = ctx.lineups[side];
  return [lu.gr].concat(lu.outfield, ctx.bench[side]||[]).filter(Boolean).find(p=>p.id===id) || null;
}
function tacLiveRender(ctx, side){
  const play = document.getElementById("ltPlay"); if(!play || !ctx || !side) return;
  const team = state.teams[side==="home"?ctx.homeId:ctx.awayId] || myTeam();
  const sis = tacSistema(team);
  const lu = ctx.lineups[side];
  const field = lu.outfield.slice();
  const lay = tacLayout(team, sis, { gr: lu.gr, field: field.slice(0,4) });
  // jogador(es) a mais em pista (ex.: sem guarda-redes): ficam junto à própria baliza
  field.slice(4).forEach((p,i)=>lay.push({ slot:{id:"x"+i,t:"W",x:11,y:50+(i%2?14:-14),lab:"+"}, player:p, out:false }));
  document.getElementById("ltRink").querySelector("svg") || document.getElementById("ltRink").insertAdjacentHTML("afterbegin", tacRinkSvg());
  const t = document.getElementById("ltTitle"); if(t) t.textContent = teamName(ctx, side);
  const sel = ltSel ? ltPlayerById(ctx, side, ltSel.id) : null;
  if(ltSel && !sel) ltSel = null;
  const finished = !!ctx.finished;
  const selKind = sel ? (sel.pos==="GR"?"GR":"J") : null;
  const existing = {};
  play.querySelectorAll(".tp-tok").forEach(e=>{ existing[e.dataset.tpP] = e; });
  play.querySelectorAll(".tp-slot").forEach(e=>e.remove());
  const keep = new Set();
  lay.forEach(x=>{
    const s = x.slot;
    const slot = document.createElement("div");
    slot.className = "tp-slot tp-slot-"+s.t; slot.style.left = s.x+"%"; slot.style.top = s.y+"%";
    slot.innerHTML = x.player ? "" : (s.lab || TAC_LAB[s.t]).replace("/","/<br>");
    play.appendChild(slot);
    if(!x.player) return;
    const p = x.player; keep.add(p.id);
    let tok = existing[p.id];
    const isNew = !tok;
    if(isNew){ tok = document.createElement("div"); tok.draggable = !finished; tok.dataset.tpP = p.id; play.appendChild(tok); }
    const fit = Math.round(p.__fitness!=null ? p.__fitness : 100);
    const eligible = !!(sel && ltSel.from==="bench" && selKind===(p.pos==="GR"?"GR":"J"));
    tok.className = "tp-tok tp-tok-"+tacKind(p)+(x.out?" out":"")+(ltSel&&ltSel.id===p.id?" sel":"")+(eligible?" elig":"");
    tok.dataset.ltRink = "1";
    tok.style.left = s.x+"%"; tok.style.top = s.y+"%";
    tok.title = p.name+" · OVR "+overall(p)+" · "+fit+"% forma";
    const marks = (p.__matchGoals?`<span class="lt-g">⚽${p.__matchGoals>1?p.__matchGoals:""}</span>`:"")+(p.__cardsThisMatch&&p.__cardsThisMatch.length?" "+cardIcons(p.__cardsThisMatch):"");
    tok.innerHTML = `<div class="tp-sh">${p.num}<span class="tp-ov">${overall(p)}</span></div><div class="tp-nm">${escapeHtml(tacSurname(p.name))}${marks}</div><div class="tp-cb"><i style="width:${fit}%;background:${fitnessColor(fit)}"></i></div>`;
  });
  Object.keys(existing).forEach(id=>{ if(!keep.has(id)) existing[id].remove(); });
  // banco
  const bench = ctx.bench[side] || [];
  const benchEl = document.getElementById("ltBench");
  benchEl.innerHTML = bench.length ? bench.map(p=>{
    const lesionado = !!p.__lesaoGraveNestaPartida;
    const fit = Math.round(p.__fitness!=null ? p.__fitness : 100);
    const eligible = !!(ltSel && ltSel.from==="rink" && ltPlayerById(ctx, side, ltSel.id) && (ltPlayerById(ctx, side, ltSel.id).pos==="GR")===(p.pos==="GR"));
    const cls = "lt-chip sub-btn"+(ltSel&&ltSel.id===p.id?" sel":"")+(eligible&&!lesionado?" elig":"")+((lesionado||finished)?" off":"");
    return `<span class="${cls}" ${(lesionado||finished)?"":'draggable="true"'} data-id="${p.id}" data-lt-bench="1" title="${escapeHtml(p.name)} · ${linhaAbbrev(p)} · OVR ${overall(p)} · ${fit}% forma${lesionado?" · lesão grave: não pode voltar":""}"><i class="tp-dot tp-dot-${tacKind(p)}">${p.num}</i>${escapeHtml(tacSurname(p.name))}<em>${overall(p)}</em><span class="lt-fit">${fit}%</span>${lesionado?" 🚑":""}</span>`;
  }).join("") : '<span class="tp-empty" style="color:#cfd6f5">Sem suplentes no banco.</span>';
  const bc = document.getElementById("ltBenchC"); if(bc) bc.textContent = bench.length+" no banco";
  if(typeof syncTaticasUI==="function") syncTaticasUI();
}
function tacLiveRefresh(){
  const ctx = state.match;
  if(ctx && ctx.live && ctx.userSide) tacLiveRender(ctx, ctx.userSide);
}
function ltTrySub(idA, idB){
  const ctx = state.match; if(!ctx || !ctx.live || ctx.finished || !ctx.userSide) return false;
  const side = ctx.userSide, lu = ctx.lineups[side];
  const a = ltPlayerById(ctx, side, idA), b = ltPlayerById(ctx, side, idB);
  if(!a || !b) return false;
  const onRink = p => p===lu.gr || lu.outfield.includes(p);
  const aOn = onRink(a), bOn = onRink(b);
  if(aOn===bOn) return false;
  const outP = aOn ? a : b, inP = aOn ? b : a;
  if((outP.pos==="GR") !== (inP.pos==="GR")){ ltMsg(inP.pos==="GR" ? "Um guarda-redes só entra por outro guarda-redes." : "O guarda-redes só pode ser trocado por outro guarda-redes."); return false; }
  if(inP.__lesaoGraveNestaPartida){ ltMsg("Lesão grave: este jogador não pode voltar a jogar."); return false; }
  performSub(ctx, side, outP, inP, "manual");
  ltSel = null;
  const mEl = document.getElementById("ltMsg"); if(mEl) mEl.classList.remove("show");
  renderScoreboard(); renderPistaBanco(ctx);
  return true;
}
function ltPick(id, from){
  const ctx = state.match; if(!ctx || !ctx.live || ctx.finished) return;
  if(ltSel && ltSel.id===id){ ltSel = null; tacLiveRefresh(); return; }
  if(ltSel && ltSel.from!==from){
    if(ltTrySub(ltSel.id, id)) return;
    // troca inválida: mantém a nova escolha
  }
  ltSel = { id, from };
  tacLiveRefresh();
  ltMsg(from==="bench" ? "Escolhe na pista quem sai." : "Escolhe no banco quem entra.");
}
document.addEventListener("click", (e)=>{
  const chip = e.target.closest && e.target.closest("#ltBench [data-lt-bench]");
  if(chip && !chip.classList.contains("off")){ ltPick(chip.dataset.id, "bench"); return; }
  const tok = e.target.closest && e.target.closest("#ltPlay .tp-tok");
  if(tok){ ltPick(tok.dataset.tpP, "rink"); }
});
document.addEventListener("dragstart", (e)=>{
  const it = e.target.closest && e.target.closest("#ltBench [data-lt-bench], #ltPlay .tp-tok"); if(!it) return;
  ltDragId = it.dataset.id || it.dataset.tpP;
  try{ e.dataTransfer.setData("text/plain", ltDragId); e.dataTransfer.effectAllowed = "move"; }catch(_){}
});
document.addEventListener("dragover", (e)=>{
  if(!ltDragId) return;
  if(e.target.closest && e.target.closest("#ltBench [data-lt-bench], #ltPlay .tp-tok")) e.preventDefault();
});
document.addEventListener("drop", (e)=>{
  if(!ltDragId) return;
  const it = e.target.closest && e.target.closest("#ltBench [data-lt-bench], #ltPlay .tp-tok");
  const from = ltDragId; ltDragId = null;
  if(!it) return;
  e.preventDefault();
  ltTrySub(from, it.dataset.id || it.dataset.tpP);
});
document.addEventListener("dragend", ()=>{ ltDragId = null; });
