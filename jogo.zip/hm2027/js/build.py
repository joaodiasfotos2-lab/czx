#!/usr/bin/env python3
"""
Junta os módulos de js/src/ (pela ordem definida em js/src/manifest.json) num único
js/app.js. O jogo continua a correr como um único ficheiro JS (sem necessidade de
servidor com suporte a módulos ES) — esta divisão existe só para facilitar a
manutenção e leitura do código-fonte.

Uso: python3 js/build.py   (a partir da pasta hm2027/)
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "src")
OUT = os.path.join(HERE, "app.js")

with open(os.path.join(SRC, "manifest.json"), encoding="utf-8") as f:
    manifest = json.load(f)

parts = []
for fname in manifest:
    with open(os.path.join(SRC, fname), encoding="utf-8") as f:
        parts.append(f.read())

body = "".join(parts)
notice = "// Ficheiro GERADO por js/build.py a partir dos módulos em js/src/ — não editar diretamente.\n// Para alterar o motor, edita o ficheiro correspondente em js/src/ e corre: python3 js/build.py\n\n"
# o corpo já inclui a linha de abertura "(function(){ ... " (no 01-nucleo.js) e o
# fecho "})();" (no 12-arranque.js) tal como no ficheiro original — só se acrescenta o
# aviso acima, para o resto ser byte a byte equivalente ao app.js anterior.
with open(OUT, "w", encoding="utf-8") as f:
    f.write(notice + body)

print(f"js/app.js gerado a partir de {len(manifest)} módulos em js/src/.")
